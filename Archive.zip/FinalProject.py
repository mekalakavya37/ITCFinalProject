
import csv

# Function to write data to CSV
def write_to_csv(filename, data):
    with open(filename, 'w', newline='', encoding='utf-8') as file:
        csv_writer = csv.writer(file)
        csv_writer.writerow(['Date', 'Review Title', 'Review'])  # Writing headers
        csv_writer.writerows(data)

# Function to scrape and write airline reviews to a CSV file
def airline_review(name):
    """
    Scrapes airline reviews for a given airline name and writes data to a CSV file.
    Args:
        name (str): Name of the airline.
    """
    import requests 
    from bs4 import BeautifulSoup as bs 
    # import csv
    url = 'https://www.airlinequality.com/airline-reviews/' + name 
    r = requests.get(url)
    soup = bs(r.content, 'html.parser')
    reviews = soup.find_all('article' , itemtype = 'http://schema.org/Review')
    data = []
    for review in reviews:
        date = review.find('time' , itemprop ='datePublished').text
        if '2023' in date:
            title = review.find('h2' , class_ = 'text_header').text
            summary = review.find('div' , class_ = 'text_content').text 
            print(f"Review Title : {title}")
            print(f"Date : {date}")
            print(f"Summary :{summary}")

            print('')  
            data.append([date, title, summary ,])       # Appending review data to list
    write_to_csv('cms_scrape-airline.csv', data)         # Writing data to CSV


# Function to scrape and write airport reviews to a CSV file
def airport_reviews(name):
    """
    Scrapes airport reviews for a given airport name and writes data to a CSV file.
    Args:
        name (str): Name of the airport.
    """
    airportt = name + '-airport'

    import requests 
    from bs4 import BeautifulSoup as bs  
    url =  'https://www.airlinequality.com/airport-reviews/' + airportt
    r = requests.get(url)
    soup = bs(r.content, 'html.parser') 
    reviews = soup.find_all('article', itemprop = 'review')
    data = []
    for r in reviews:
        date = r.find('time' , itemprop = 'datePublished').text
        title = r.find('h2' , class_ = 'text_header').text
        summary = r.find('div' , class_ = 'text_content').text
        print(f"Title : {title}")
        print(f"Date : {date}")
        print(f"Summary : {summary}")

        print(f'')
        data.append([date, title, summary])              # Appending review data to list
    write_to_csv('cms_scrape-airport.csv', data)         # Writing data to CSV

def seat_reviews(name):
    """
    Scrapes seat reviews for a given airline name and writes data to a CSV file.
    Includes extraction of table information from the reviews.
    Args:
        name (str): Name of the airline.
    """
    import requests 
    from bs4 import BeautifulSoup as bs 
    import csv

    url = 'https://www.airlinequality.com/seat-reviews/' + name 
    r = requests.get(url)
    soup = bs(r.content, 'html.parser')
    reviews = soup.find_all('article', itemprop='review' , itemtype = 'http://schema.org/Review')
    data = []

    for review in reviews:
        date = review.find('time', itemprop='datePublished').text
        if '2023' in date:
            title = review.find('h2', class_='text_header').text
            summary = review.find('div', class_='text_content').text

            # Extracting table information
            table_data = ''
            table = review.find('table', class_='review-ratings')
            if table:
                table_rows = table.find_all('tr')
                for row in table_rows:
                    cells = row.find_all(['th', 'td'])
                    for cell in cells:
                        table_data += cell.get_text(strip=True) + ' | '

            print(f"Review Title : {title}")
            print(f"Date : {date}")
            print(f"Review : {summary}")
            print(f"Table : {table_data}\n")

            data.append([date, title, summary, table_data])    # Writing data to CSV

    write_to_csv('cms_scrape-seatss.csv', data)


# Function to scrape and write lounge reviews to a CSV file
def lounge_reviews(name):
    """
    Scrapes lounge reviews for a given airport name and writes data to a CSV file.
    Args:
        name (str): Name of the airport.
    """
    import requests 
    from bs4 import BeautifulSoup as bs 
    import csv 

    url = 'https://www.airlinequality.com/lounge-reviews/' + name 
    r = requests.get(url)
    soup = bs(r.content, 'html.parser') 
    reviews = soup.find_all('article', itemprop='review')
    data = []
    
    for j in reviews: 
        date = j.find('time' , itemprop = 'datePublished').text
        title = j.find('h2', class_='text_header').text
        summary = j.find('div', class_='text_content').text
        airport = j.find('td', class_='review-value').text

        print(f"Date : {date}")
        print(f"Lounge : {airport}")
        print(f"Title : {title}")
        print(f"Summary : {summary}")

        print('')
        data.append([date, title, airport, summary])
    write_to_csv('cms_scrape-lounge.csv', data)


# Function to take user input and run the desired scraping function
def maincode():
    name = input("Enter airways : ")
    options = input(" Select one option, 1. Airline Review , 2. Seat Review , 3. Lounge Review , 4. Airport Review:")

    if options == '1':
        airline_review(name)
    elif options == '2':
        seat_reviews(name)
    elif options == '3':
        lounge_reviews(name)
    elif options == '4':
        airport_reviews(name)
    else:
        print("INVALID INPUT")


maincode()





